"""STEP 1: Data Collection from APIs and Web Scraping"""
from .collect import *
from .scrape import *
